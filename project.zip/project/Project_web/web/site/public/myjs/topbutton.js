$(document).ready(function(){
    $("#topsearch").click(function(){
        location.href="./search.html";
    });
});