function callPython(pyFile, arg) {
    const exec = require('child_process').exec;
    exec('python' + ' ' + pyFile + ' ' + arg, function (err, stdout, stderr) {
        if (err) {
            console.log('stderr', err);
        }
        if (stdout) {
            console.log('stdout', stdout);
        }
        if (stderr) {
            console.info('stderr : ' + stderr);
        }
    });
}

function calcModel(T) {
    callPython('python/model.py', T);
}

function calcPrediction(length) {
    callPython('python/prediction.py', length);
}

module.exports = {
    calcModel,
    calcPrediction,
}