# -*- coding: utf-8 -*-
"""
Created on Sat Aug 15 11:02:40 2020

@author: PPC
"""

import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from keras.layers.core import Dense, Activation, Dropout
from keras.layers.recurrent import LSTM
from keras.models import Sequential
import pandas


def dataNorm(data):
    return [(i - data[0]) / data[0] for i in data]


def dataDeNorm(data, base):
    return (data + 1) * base


def predict(model, X):
    predictionsNorm = []
    for i in range(len(X)):
        data = X[i]

        result = []
        for j in range(10):
            predicted = model.predict(data[np.newaxis, :, :])[0, 0]
            result.append(predicted)
            data = data[1:]
            data = np.insert(data, 10 - 1, predicted, axis=0)
        predictionsNorm.append(result)
    return predictionsNorm


def plot(Y_hat, Y):
    plt.plot(Y)
    for i in range(len(Y_hat)):
        padding = [None for _ in range(i * 10)]
        plt.plot(padding + Y_hat[i])
    plt.show()


def getData():
    # 读入数据
    data = np.array(pandas.read_csv('1.csv'))
    data = data[:, 4][::-1].tolist()
    print(data)

    for i in range(len(data)):
        data[i] = data[i][0] + data[i][2] + data[i][3] + data[i][4] + data[i][5] + data[i][6] + data[i][7]
        data[i] = float(data[i])

    # 建立训练集
    dataTraining = []
    for i in range(len(data) - 11 - 20):
        dataSegment = data[i:i + 11]

        dataTraining.append(dataNorm(dataSegment))
    dataTraining = np.array(dataTraining)
    X_Training = dataTraining[:, :-1]
    Y_Training = dataTraining[:, -1]

    # 建立测试集
    X_Testing = []
    Y_Testing_base = []
    for i in range(len(data) - 11 - 20, len(data) - 11):
        dataSegment = data[i:i + 11]
        Y_Testing_base.append(dataSegment[10])
        X_Testing.append(dataNorm(dataSegment[0:10]))
    Y_Testing = data[-20:]
    X_Testing = np.array(X_Testing)
    Y_Testing = np.array(Y_Testing)
    X_Training = np.reshape(X_Training, (X_Training.shape[0], X_Training.shape[1], 1))
    X_Testing = np.reshape(X_Testing, (X_Testing.shape[0], X_Testing.shape[1], 1))

    return X_Training, Y_Training, X_Testing, Y_Testing, Y_Testing_base


def predictLSTM():
    X_Training, Y_Training, X_Testing, Y_Testing, Y_Testing_base = getData()

    # 读入股票数据

    # 建立模型
    model = Sequential()

    model.add(LSTM(input_dim=1, units=50, return_sequences=True))
    model.add(Dropout(0.2))
    model.add(LSTM(200, return_sequences=False))
    model.add(Dropout(0.2))
    model.add(Dense(units=1))
    model.add(Activation('linear'))
    model.compile(loss='mse', optimizer='rmsprop')
    # 训练
    model.fit(X_Training, Y_Training, batch_size=64, validation_split=0.05)
    return model


def predict_by_data_set(model, data_set):
    # 预测 用前十天的数据预测第十一天的数据
    # a = [3970.99, 3990.16, 4002.96, 4019.15, 4094.94, 4164.51, 4174.64, 4178.27, 4194.96, 4197.43]  # a为前十天的数据
    a1 = dataNorm(data_set)
    a1 = np.array(a1)
    a1 = a1[np.newaxis, :, np.newaxis]
    predictNorm = model.predict(a1)[0][0]
    print(predictNorm)
    predictions = dataDeNorm(predictNorm, data_set[0])
    print('预测第N+1天的收盘价为', predictions)  # predictions 为通过前十天的数据预测得到的第十一天的数据
    return predictions


def plotXY(X, Y):
    plt.plot(X, Y, 'o-', color='red', label='label')
    plt.xlabel("Days")
    plt.ylabel("Closing price")
    plt.legend(loc='best')
    my_x_ticks = np.arange(0, len(X) + 1, 1)
    plt.xticks(my_x_ticks)
    # plt.show()
    plt.savefig('public/image/prediction.jpg')
    print('success')


if __name__ == '__main__':
    import sys
    argv = sys.argv
    length = int(argv[-1])
    time = 3
    model = predictLSTM()
    data_set = [3970.99, 3990.16, 4002.96, 4019.15, 4094.94, 4164.51, 4174.64, 4178.27, 4194.96, 4197.43]  # 前十天的数据
    for _ in range(10, length + 1):
        predict_n = round(predict_by_data_set(model, data_set), 2)
        data_set.append(predict_n)
    X = []
    for i, _ in enumerate(data_set):
        X.append(i + 1)
    print(data_set)
    print("最终预测第" + str(length + 1) + "天的收盘价为" + str(data_set[-1]))
    plotXY(X, data_set)
